# Snake-Game
The Snake game is a classic and straightforward arcade-style video game that has been popular for decades. It is a classic and 
nostalgic game for many people. the objective is to eat as much food as possible without crashing into obstacles, which becomes 
increasingly challenging as the snake grows longer.
